#imports - needed in android studio aswell
from tensorflow import keras
from keras.models import *
import numpy as np
import rawpy
import matplotlib.pyplot as plt

path = "C:/Users/oszil/Egyetem/BME/5/deep/Sony_test_list.txt"
replace = "C:/Users/oszil/Egyetem/BME/5/deep"

def load(path):
    Data = []
    with open(path) as Path:
        for line in Path:
            data, truth, _, _ = line.split()
            data = data.replace(".", replace, 1)
            truth = truth.replace(".", replace, 1)
            Data.append([data, truth])
    print(len(Data))
    return Data

def Ratio(in_path, truth_path):
    in_exposure = float(in_path[55:-5])
    gt_exposure = float(truth_path[54:-5])
    print(in_exposure)
    ratio = min(gt_exposure / in_exposure, 300)
    return ratio

def predict():
    #load in the model
    Model = load_model('my_model')
    #Model.summary()

    #load in the test raw image
    test = load(path)
    #print(test[0][0])
    #print(test[1][0])
    raw = rawpy.imread(test[1][0])
    raw = raw.postprocess(use_camera_wb=True, half_size=False, no_auto_bright=True, output_bps=16)
    raw = np.expand_dims(np.float32(raw / 65535.0), axis=0)
    input_patch = raw * Ratio(test[1][0], test[1][1])
    input_patch = np.minimum(input_patch, 1.0)

    test_out = Model.predict(input_patch)
    test_out = test_out
    test_out = ((np.minimum(np.maximum(0, test_out), 1) * 255)).astype(int)
    test_out = test_out.reshape(test_out.shape[1], test_out.shape[2], test_out.shape[3])
    print(test_out.shape)

    #test_ground = rawpy.imread(test[1][1])
    #test_ground = test_ground.postprocess()

    fig, axes = plt.subplots(2, 1, figsize=(30, 30))
    axes[0].imshow(test_out, interpolation='nearest')
    #axes[1].imshow(test_ground, interpolation='nearest')
    plt.show()

predict()

