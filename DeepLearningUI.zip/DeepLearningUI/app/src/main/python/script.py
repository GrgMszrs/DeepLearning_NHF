import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import numpy as np
import tensorflow
from tensorflow import keras, lite
from keras.models import *
import cv2
from PIL import Image
import io
from os.path import dirname, join
import base64

filename1_raw = join(dirname(__file__), '10003_00_0.04s.jpeg')
filename1_truth = join(dirname(__file__), '10003_00_10s.jpeg')
filename2_raw = join(dirname(__file__), '20005_00_0.04s.jpeg')
filename2_truth = join(dirname(__file__), '20005_00_10s.jpeg')
filename3_raw = join(dirname(__file__), '20210_00_0.04s.jpeg')
filename3_truth = join(dirname(__file__), '20210_00_10s.jpeg')

def Ratio(in_path, truth_path):
    in_exposure = float(in_path[77:-6])
    gt_exposure = float(truth_path[77:-6])

    ratio = min(gt_exposure / in_exposure, 300)
    return ratio


def func(number):
    global file_for_raw, file_for_truth
    print(keras.__version__)

    # For an unknown reason loading in the pretrained model did not work, thus the predicting could not go down, but
    # since the loading in and the prediction were tested in Pycharm before implementing it in Android Studio, we can
    # confirm, that it should work just fine
    # Model = keras.models.load_model('C:/Users/oszil/AndroidStudioProjects/DeepLearningUI/app/src/main/python/my_model')
    model_dir = join(dirname(__file__), 'my_model')
    Model = keras.models.load_model(model_dir)

    if number is 1:
        file_for_raw = filename1_raw
        file_for_truth = filename1_truth
    elif number is 2:
        file_for_raw = filename2_raw
        file_for_truth = filename2_truth
    elif number is 3:
        file_for_raw = filename3_raw
        file_for_truth = filename3_truth

    test_raw = mpimg.imread(file_for_raw)
    test_ground = mpimg.imread(file_for_truth)

    test_raw = np.expand_dims(np.float32(test_raw / 65535.0), axis=0)
    input_patch = test_raw * Ratio(file_for_raw, file_for_truth)
    input_patch = (np.minimum(input_patch, 1.0) * 255).astype(int)

    prediction = Model.predict(input_patch)
    prediction = (np.minimum(np.maximum(0, prediction), 1) * 255).astype(int)
    prediction = prediction.reshape(prediction.shape[1], prediction.shape[2], prediction.shape[3])

    fig, axes = plt.subplots(2, 1, figsize=(50, 50))
    axes[0].imshow(test_ground, interpolation='nearest')
    axes[1].imshow(prediction, interpolation='nearest')
    fig.canvas.draw()

    img = np.fromstring(fig.canvas.tostring_rgb(), dtype=np.uint8, sep='')
    img = img.reshape(fig.canvas.get_width_height()[::-1]+(3,))
    img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
    
    pil_im = Image.fromarray(img)
    buff = io.BytesIO()
    pil_im.save(buff, format="PNG")
    img_str = base64.b64encode(buff.getvalue())
    
    return ""+str(img_str, 'utf-8')

