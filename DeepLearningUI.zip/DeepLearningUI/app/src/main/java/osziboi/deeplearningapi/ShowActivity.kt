package osziboi.deeplearningapi

import android.graphics.BitmapFactory
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_second.*

class ShowActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        val number = intent.getIntExtra(NUM, -1)
        initPy()
        val python = Python.getInstance()
        val pythonFile = python.getModule("script")
        val obj = pythonFile.callAttr("func", number).toString()
        val data = android.util.Base64.decode(obj, 0)
        val bmp = BitmapFactory.decodeByteArray(data, 0, data.size)

        imagetoprint.setImageBitmap(bmp)
    }

    private fun initPy(){
        if(!Python.isStarted()){
            Python.start(AndroidPlatform(this))
        }
    }

    companion object{
        const val NUM = "num"
    }
}