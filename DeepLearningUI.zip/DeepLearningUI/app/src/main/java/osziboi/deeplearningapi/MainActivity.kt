package osziboi.deeplearningapi

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initPy()
        first.text = pyScript()
    }

    private fun initPy(){
        if(!Python.isStarted()){
            Python.start(AndroidPlatform(this))
        }
    }

    private fun pyScript() : String{
        val python = Python.getInstance()
        val pythonFile = python.getModule("script")
        return pythonFile.callAttr("predict").toString()
    }


}