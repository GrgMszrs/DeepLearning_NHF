package osziboi.deeplearningapi

import android.content.Intent
import android.graphics.BitmapFactory
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Base64.DEFAULT
import android.view.View
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import com.google.android.material.snackbar.Snackbar
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        first.setOnClickListener {
            val int = Intent()
            int.setClass(this, ShowActivity::class.java)
            int.putExtra(ShowActivity.NUM, 1)
            startActivity(int)
        }

        second.setOnClickListener {
            val int = Intent()
            int.setClass(this, ShowActivity::class.java)
            int.putExtra(ShowActivity.NUM, 2)
            startActivity(int)
        }

        third.setOnClickListener {
            val int = Intent()
            int.setClass(this, ShowActivity::class.java)
            int.putExtra(ShowActivity.NUM, 3)
            startActivity(int)
        }
            }
}